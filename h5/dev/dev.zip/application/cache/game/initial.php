<?php

return array (
  'B' => 
  array (
    0 => 
    array (
      'game_id' => '9',
      'name' => '不良人',
      'initial' => 'B',
      'visible' => '0',
      'prepay' => '1',
    ),
  ),
  'D' => 
  array (
    0 => 
    array (
      'game_id' => '7',
      'name' => '地下城勇士',
      'initial' => 'D',
      'visible' => '1',
      'prepay' => '0',
    ),
  ),
  'G' => 
  array (
    0 => 
    array (
      'game_id' => '2',
      'name' => '钢管儿上传的游戏',
      'initial' => 'G',
      'visible' => '1',
      'prepay' => '0',
    ),
  ),
  'S' => 
  array (
    0 => 
    array (
      'game_id' => '8',
      'name' => '神奇六边形',
      'initial' => 'S',
      'visible' => '0',
      'prepay' => '1',
    ),
  ),
  'W' => 
  array (
    0 => 
    array (
      'game_id' => '3',
      'name' => '我勒个去',
      'initial' => 'W',
      'visible' => '1',
      'prepay' => '0',
    ),
  ),
  'Y' => 
  array (
    0 => 
    array (
      'game_id' => '1',
      'name' => '愚公移山',
      'initial' => 'Y',
      'visible' => '1',
      'prepay' => '0',
    ),
  ),
);
