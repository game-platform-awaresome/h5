<?php

return array (
  0 => 
  array (
    'reward_id' => '1',
    'type' => 'serial',
    'days' => '1',
    'times' => '0',
    'reward' => 
    array (
      0 => 
      array (
        0 => 'integral',
        1 => '积分',
        2 => '50',
      ),
    ),
    'reset' => '0',
    'disabled' => '0',
  ),
  1 => 
  array (
    'reward_id' => '2',
    'type' => 'serial',
    'days' => '2',
    'times' => '0',
    'reward' => 
    array (
      0 => 
      array (
        0 => 'integral',
        1 => '积分',
        2 => '100',
      ),
    ),
    'reset' => '0',
    'disabled' => '0',
  ),
  2 => 
  array (
    'reward_id' => '3',
    'type' => 'serial',
    'days' => '3',
    'times' => '0',
    'reward' => 
    array (
      0 => 
      array (
        0 => 'integral',
        1 => '积分',
        2 => '150',
      ),
    ),
    'reset' => '0',
    'disabled' => '0',
  ),
  3 => 
  array (
    'reward_id' => '4',
    'type' => 'serial',
    'days' => '4',
    'times' => '0',
    'reward' => 
    array (
      0 => 
      array (
        0 => 'integral',
        1 => '积分',
        2 => '200',
      ),
    ),
    'reset' => '0',
    'disabled' => '0',
  ),
  4 => 
  array (
    'reward_id' => '5',
    'type' => 'total',
    'days' => '10',
    'times' => '0',
    'reward' => 
    array (
      0 => 
      array (
        0 => 'integral',
        1 => '积分',
        2 => '500',
      ),
    ),
    'reset' => '0',
    'disabled' => '0',
  ),
  5 => 
  array (
    'reward_id' => '6',
    'type' => 'total',
    'days' => '20',
    'times' => '0',
    'reward' => 
    array (
      0 => 
      array (
        0 => 'integral',
        1 => '积分',
        2 => '1000',
      ),
    ),
    'reset' => '0',
    'disabled' => '0',
  ),
  6 => 
  array (
    'reward_id' => '7',
    'type' => 'total',
    'days' => '30',
    'times' => '0',
    'reward' => 
    array (
      0 => 
      array (
        0 => 'integral',
        1 => '积分',
        2 => '2000',
      ),
    ),
    'reset' => '1',
    'disabled' => '0',
  ),
);
