<?php

return array (
  'pos_id' => '10',
  'pos_code' => 'game_index_special',
  'preview' => '',
  'name' => '游戏首页-今日特别推荐',
  'width' => '299',
  'height' => '136',
  'image' => '/game/ad_pos/10.png?1445491904',
  'subject' => '',
  'url' => '',
  'can_apply' => '0',
  'display' => '10',
  'ads' => 
  array (
    0 => 
    array (
      'ad_id' => '10',
      'image' => '/game/ad_ins/10.png?1445492061',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
    1 => 
    array (
      'ad_id' => '11',
      'image' => '/game/ad_ins/11.png?1445492070',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
  ),
);
