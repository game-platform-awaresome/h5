<?php

return array (
  'pos_id' => '9',
  'pos_code' => 'article_detail_banner',
  'preview' => '',
  'name' => '资讯详情-banner',
  'width' => '599',
  'height' => '220',
  'image' => '/game/ad_pos/9.jpg?1445477463',
  'subject' => '',
  'url' => '',
  'can_apply' => '0',
  'display' => '0',
  'ads' => 
  array (
  ),
);
