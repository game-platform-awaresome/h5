<?php

return array (
  'pos_id' => '16',
  'pos_code' => 'game_index_activity',
  'preview' => '',
  'name' => '首页-最新活动',
  'width' => '576',
  'height' => '220',
  'image' => '/game/ad_pos/16.jpg?1449818524',
  'subject' => '',
  'url' => '',
  'can_apply' => '0',
  'display' => '15',
  'ads' => 
  array (
    0 => 
    array (
      'ad_id' => '20',
      'image' => '/game/ad_ins/20.jpg?1449818551',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
    1 => 
    array (
      'ad_id' => '21',
      'image' => '/game/ad_ins/21.jpg?1449818562',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
  ),
);
