<?php

return array (
  'pos_id' => '3',
  'pos_code' => 'game_index_forum',
  'preview' => '',
  'name' => '游戏首页-论坛',
  'width' => '287',
  'height' => '120',
  'image' => '/game/ad_pos/3.jpg?20150914',
  'subject' => '',
  'url' => '',
  'can_apply' => '0',
  'display' => '0',
  'ads' => 
  array (
  ),
);
