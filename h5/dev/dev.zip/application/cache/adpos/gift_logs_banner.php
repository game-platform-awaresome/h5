<?php

return array (
  'pos_id' => '12',
  'pos_code' => 'gift_logs_banner',
  'preview' => '',
  'name' => '礼包记录-Banner',
  'width' => '623',
  'height' => '204',
  'image' => '/game/ad_pos/12.png?1445847907',
  'subject' => '',
  'url' => '',
  'can_apply' => '0',
  'display' => '12',
  'ads' => 
  array (
  ),
);
