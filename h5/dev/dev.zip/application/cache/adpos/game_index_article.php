<?php

return array (
  'pos_id' => '2',
  'pos_code' => 'game_index_article',
  'preview' => '',
  'name' => '游戏首页-资讯',
  'width' => '287',
  'height' => '120',
  'image' => '/game/ad_pos/2.jpg?20150914',
  'subject' => '《使命召唤》<br>今日开放测试，等你来拿',
  'url' => '',
  'can_apply' => '0',
  'display' => '0',
  'ads' => 
  array (
  ),
);
