<?php

return array (
  'pos_id' => '1',
  'pos_code' => 'game_index_banner',
  'preview' => '',
  'name' => '游戏首页Banner',
  'width' => '640',
  'height' => '282',
  'image' => '/game/ad_pos/1.jpg',
  'subject' => '',
  'url' => '',
  'can_apply' => '0',
  'display' => '0',
  'ads' => 
  array (
    0 => 
    array (
      'ad_id' => '1',
      'image' => '/game/ad_ins/1.jpg',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
    1 => 
    array (
      'ad_id' => '5',
      'image' => '/game/ad_ins/5.jpg?20150914',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
  ),
);
