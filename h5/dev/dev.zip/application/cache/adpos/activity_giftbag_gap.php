<?php

return array (
  'pos_id' => '13',
  'pos_code' => 'activity_giftbag_gap',
  'preview' => '',
  'name' => '礼包中心-间隙广告',
  'width' => '581',
  'height' => '116',
  'image' => '/game/ad_pos/13.png?1445915012',
  'subject' => '',
  'url' => '',
  'can_apply' => '0',
  'display' => '13',
  'ads' => 
  array (
  ),
);
