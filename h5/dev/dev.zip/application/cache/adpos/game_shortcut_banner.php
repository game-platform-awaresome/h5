<?php

return array (
  'pos_id' => '14',
  'pos_code' => 'game_shortcut_banner',
  'preview' => '',
  'name' => '游戏首页-快速通道下方广告',
  'width' => '595',
  'height' => '135',
  'image' => '/game/ad_pos/14.jpg?1447057362',
  'subject' => '',
  'url' => '',
  'can_apply' => '0',
  'display' => '14',
  'ads' => 
  array (
  ),
);
