<?php

return array (
  'pos_id' => '5',
  'pos_code' => 'pay_center_banner',
  'preview' => '',
  'name' => '充值中心Banner',
  'width' => '623',
  'height' => '204',
  'image' => '/game/ad_pos/5.jpg?20150914',
  'subject' => '',
  'url' => '',
  'can_apply' => '0',
  'display' => '6',
  'ads' => 
  array (
  ),
);
