<?php

return array (
  'pos_id' => '6',
  'pos_code' => 'game_index_recommend',
  'preview' => '',
  'name' => '游戏首页-推荐游戏',
  'width' => '100',
  'height' => '100',
  'image' => '/game/ad_pos/6.png?20150914',
  'subject' => '',
  'url' => '',
  'can_apply' => '0',
  'display' => '0',
  'ads' => 
  array (
    0 => 
    array (
      'ad_id' => '2',
      'image' => '/game/ad_ins/2.png',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
    1 => 
    array (
      'ad_id' => '4',
      'image' => '/game/ad_ins/4.png',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
    2 => 
    array (
      'ad_id' => '3',
      'image' => '/game/ad_ins/3.png',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
  ),
);
