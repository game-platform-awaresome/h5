<?php

return array (
  'pos_id' => '15',
  'pos_code' => 'open_list_banner',
  'preview' => '',
  'name' => '开服详情-Banner',
  'width' => '598',
  'height' => '136',
  'image' => '/game/ad_pos/15.jpg?1447666387',
  'subject' => '',
  'url' => '',
  'can_apply' => '0',
  'display' => '0',
  'ads' => 
  array (
  ),
);
