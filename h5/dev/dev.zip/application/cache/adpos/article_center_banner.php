<?php

return array (
  'pos_id' => '4',
  'pos_code' => 'article_center_banner',
  'preview' => '',
  'name' => '资讯中心Banner',
  'width' => '600',
  'height' => '220',
  'image' => '/game/ad_pos/4.jpg?20150914',
  'subject' => '《使命召唤》<br>今日开放测试，等你来拿',
  'url' => '',
  'can_apply' => '0',
  'display' => '0',
  'ads' => 
  array (
  ),
);
