<?php

return array (
  'pos_id' => '8',
  'pos_code' => 'article_recommend_2',
  'preview' => '',
  'name' => '资讯中心-推荐新闻',
  'width' => '287',
  'height' => '120',
  'image' => '/game/ad_pos/8.png?1445394690',
  'subject' => '',
  'url' => '',
  'can_apply' => '0',
  'display' => '0',
  'ads' => 
  array (
    0 => 
    array (
      'ad_id' => '8',
      'image' => '/game/ad_ins/8.png?1445394753',
      'subject' => '《使命召唤》<br>今日开放测试，等你来拿',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
    1 => 
    array (
      'ad_id' => '9',
      'image' => '/game/ad_ins/9.png?1445394808',
      'subject' => '《一招变土豪》<br>快速攻略启动，速来',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
  ),
);
