<?php

return array (
  'pos_id' => '7',
  'pos_code' => 'game_center_2col',
  'preview' => '/game/ad_pos/7-preview.png?1445052206',
  'name' => '游戏中心-搜索框下2并排广告',
  'width' => '293',
  'height' => '115',
  'image' => '/game/ad_pos/7.png?1445052206',
  'subject' => '',
  'url' => '',
  'can_apply' => '0',
  'display' => '0',
  'ads' => 
  array (
    0 => 
    array (
      'ad_id' => '6',
      'image' => '/game/ad_ins/6.png?1445052232',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
    1 => 
    array (
      'ad_id' => '7',
      'image' => '/game/ad_ins/7.png?1445052239',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
  ),
);
