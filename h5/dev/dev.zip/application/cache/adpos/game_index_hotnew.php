<?php

return array (
  'pos_id' => '11',
  'pos_code' => 'game_index_hotnew',
  'preview' => '',
  'name' => '游戏首页-火爆新游',
  'width' => '100',
  'height' => '100',
  'image' => '/game/ad_pos/11.png?1445492020',
  'subject' => '',
  'url' => '',
  'can_apply' => '0',
  'display' => '11',
  'ads' => 
  array (
    0 => 
    array (
      'ad_id' => '12',
      'image' => '/game/ad_ins/12.png?1445492114',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
    1 => 
    array (
      'ad_id' => '13',
      'image' => '/game/ad_ins/13.png?1445492120',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
    2 => 
    array (
      'ad_id' => '14',
      'image' => '/game/ad_ins/14.png?1445492124',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
    3 => 
    array (
      'ad_id' => '15',
      'image' => '/game/ad_ins/15.png?1445492131',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
    4 => 
    array (
      'ad_id' => '16',
      'image' => '/game/ad_ins/16.png?1445492137',
      'subject' => '',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
    5 => 
    array (
      'ad_id' => '17',
      'image' => '/game/ad_ins/17.png?1447061785',
      'subject' => '2222',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
    6 => 
    array (
      'ad_id' => '18',
      'image' => '/game/ad_ins/18.png?1447061795',
      'subject' => '3333',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
    7 => 
    array (
      'ad_id' => '19',
      'image' => '/game/ad_ins/19.png?1447061802',
      'subject' => '4444',
      'url' => '',
      'on_time' => '0',
      'off_time' => '0',
    ),
  ),
);
