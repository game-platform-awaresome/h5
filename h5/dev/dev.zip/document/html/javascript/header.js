document.write('<div class="header">');
document.write('<a class="logo" href="#" title="UCenter">UCenter</a>');
document.write('<div class="uinfo">');
document.write('<p id="others"><a href="#" class="othersoff" onclick="showmenu(this);">手册导航</a></p>');
document.write('</div></div>');
document.write('<div class="wrap" id="wrap">');
documentmenu(1);
document.write('<div class="mainbox">');