--清空临时数据

truncate table game;
truncate table game_detail;
truncate table game_search;
truncate table server;

truncate table ad_instance;
truncate table article;
truncate table admin_log;
truncate table signon_log;

truncate table user_cdkey;
truncate table user_favorites;
truncate table user_games;
truncate table user_servers;

truncate table smscode_ip;
truncate table smscode_mobile;
